!function ($) {
  
  $(document).ready(function($) {
    $(document).on("click",".btn-access-comment-tab", function(event) {
    	$(".explorer-tab-comments > A")[0].click();
    });  	
  });
  
  
}(window.jQuery);